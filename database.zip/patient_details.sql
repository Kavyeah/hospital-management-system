-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 21, 2019 at 11:09 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `kavya`
--

-- --------------------------------------------------------

--
-- Table structure for table `patient_details`
--

CREATE TABLE IF NOT EXISTS `patient_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `phone_number` varchar(11) DEFAULT NULL,
  `email_id` varchar(50) DEFAULT NULL,
  `disorder` varchar(100) DEFAULT NULL,
  `ward_num` int(11) DEFAULT NULL,
  `doctor_consulted` varchar(100) DEFAULT NULL,
  `amt` int(11) DEFAULT NULL,
  `due` int(11) DEFAULT NULL,
  `admitted_date` varchar(100) DEFAULT NULL,
  `discharged_date` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `patient_details`
--

INSERT INTO `patient_details` (`id`, `name`, `phone_number`, `email_id`, `disorder`, `ward_num`, `doctor_consulted`, `amt`, `due`, `admitted_date`, `discharged_date`) VALUES
(1, 'kavya', '99801626300', 'kavyasriprabha@gmail.com', 'fever', 102, 'raja', 12000, 0, '12/3/1998', '15/3/1998');
